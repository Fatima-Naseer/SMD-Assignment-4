package com.example.roomdatabase;

import androidx.room.Dao;
import androidx.room.Insert;

@Dao
public interface location_tracking_Dao {
    @Insert
    public void addLocationTrack(location_tracking locationTracking);
}
