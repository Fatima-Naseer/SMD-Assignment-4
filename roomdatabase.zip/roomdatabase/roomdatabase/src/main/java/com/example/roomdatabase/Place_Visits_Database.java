package com.example.roomdatabase;

import androidx.room.Database;
import androidx.room.RoomDatabase;

@Database(entities = (place_visits.class), version = 1)
public abstract class Place_Visits_Database extends RoomDatabase {
    public abstract place_visits_Dao place_visits_dao();
}
