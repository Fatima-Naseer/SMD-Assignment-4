package com.example.roomdatabase;

import androidx.room.Dao;
import androidx.room.Insert;

@Dao
public interface place_visits_Dao {
    @Insert
    public void addPlaceVisit(place_visits placeVisits);
}
