package com.example.roomdatabase;

import androidx.room.Database;
import androidx.room.RoomDatabase;

@Database(entities = (location_tracking.class), version = 1)
public abstract class Location_Tracking_Database extends RoomDatabase {
    public abstract location_tracking_Dao location_tracking_dao();
}
