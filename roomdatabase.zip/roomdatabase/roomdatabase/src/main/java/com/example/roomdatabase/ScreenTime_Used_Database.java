package com.example.roomdatabase;

import androidx.room.Database;
import androidx.room.RoomDatabase;

@Database(entities = (screentime_used.class), version = 1)
public abstract class ScreenTime_Used_Database extends RoomDatabase {
    public abstract screentime_used_Dao screentime_used_dao();
}
