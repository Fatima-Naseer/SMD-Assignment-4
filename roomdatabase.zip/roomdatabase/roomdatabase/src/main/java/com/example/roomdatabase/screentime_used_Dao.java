package com.example.roomdatabase;

import androidx.room.Dao;
import androidx.room.Insert;

@Dao
public interface screentime_used_Dao {
    @Insert
    public void addScreenTimeUsed(screentime_used screentimeUsed);
}
